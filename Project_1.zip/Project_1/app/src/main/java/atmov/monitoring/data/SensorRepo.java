package atmov.monitoring.data;

public class SensorRepo {
}
