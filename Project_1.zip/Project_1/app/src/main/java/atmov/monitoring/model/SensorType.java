package atmov.monitoring.model;
/**
 * Defines the supported sensor types in the application.
 * Provides constant identifiers for temperature, humidity,
 * and light sensors.
 */
public class SensorType {
    public static final String TEMPERATURE = "TEMP";

    public static final String HUMIDITY = "HUM";

    public static final String LIGHT = "LIGHT";
    /**
     * Private constructor to prevent the creation
     * of SensorType objects.
     */
    private SensorType() {
    }
}
