package atmov.monitoring;

import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.ScrollView;
/**
 * Custom ScrollView with a maximum height.
 * Automatically adjusts its height based on its content,
 * up to a predefined limit. If the content exceeds this
 * limit, vertical scrolling is enabled.
 */
public class MaxHeightScrollView extends ScrollView {

    private static final int MAX_HEIGHT_DP = 220;
    /**
     * Creates a MaxHeightScrollView from an XML layout.
     * @param context Application context.
     * @param attrs Attributes defined in the XML layout.
     */
    public MaxHeightScrollView(
            Context context,
            AttributeSet attrs) {

        super(context, attrs);
    }

    /**
     * Measures the ScrollView dimensions while enforcing
     * a maximum height.
     * @param widthMeasureSpec Width requirements from the parent.
     * @param heightMeasureSpec Height requirements from the parent.
     */
    @Override
    protected void onMeasure(
            int widthMeasureSpec,
            int heightMeasureSpec) {

        int maxHeight = (int)
                TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP,
                        MAX_HEIGHT_DP,
                        getResources().getDisplayMetrics()
                );

        int mode = MeasureSpec.getMode(heightMeasureSpec);
        int availableHeight = MeasureSpec.getSize(heightMeasureSpec);

        int limit = mode == MeasureSpec.UNSPECIFIED
                ? maxHeight
                : Math.min(maxHeight, availableHeight);

        int newHeightSpec = MeasureSpec.makeMeasureSpec(
                limit,
                MeasureSpec.AT_MOST
        );

        super.onMeasure(widthMeasureSpec, newHeightSpec);
    }
}