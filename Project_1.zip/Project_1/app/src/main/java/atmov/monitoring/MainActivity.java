
package atmov.monitoring;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import atmov.monitoring.notifications.NotificationPanelController;

/**
 * Main screen of the Monitoring and Alarm System.
 * Handles navigation, theme switching, and the
 * initialization of the notification panel.
 */
public class MainActivity extends AppCompatActivity {

    private NotificationPanelController notificationPanel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Restore the saved theme preference.
        SharedPreferences preferences =
                getSharedPreferences("theme_preferences", MODE_PRIVATE);

        boolean darkMode =
                preferences.getBoolean("dark_mode", false);

        int selectedMode = darkMode
                ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_NO;

        if (AppCompatDelegate.getDefaultNightMode() != selectedMode) {
            AppCompatDelegate.setDefaultNightMode(selectedMode);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        // Initialize navigation buttons.
        ImageButton btnSensors = findViewById(R.id.btnSensors);
        ImageButton btnSettings = findViewById(R.id.btnSettings);
        ImageButton btnHistory = findViewById(R.id.btnHistory);
        ImageButton btnDarkMode = findViewById(R.id.btnDarkMode);


        // Initialize the notification panel.
        notificationPanel = new NotificationPanelController(
                this,
                findViewById(R.id.notificationsContainer),
                findViewById(R.id.tvEmptyNotifications)
        );


        // Navigation events.
        btnSensors.setOnClickListener(v -> showModuleNotReady());
        btnSettings.setOnClickListener(v -> showModuleNotReady());
        btnHistory.setOnClickListener(v -> showModuleNotReady());


        // Toggle between light and dark themes.
        btnDarkMode.setOnClickListener(v -> {

            boolean isDark =
                    preferences.getBoolean("dark_mode", false);

            boolean newDarkMode = !isDark;

            preferences.edit()
                    .putBoolean("dark_mode", newDarkMode)
                    .apply();

            AppCompatDelegate.setDefaultNightMode(
                    newDarkMode
                            ? AppCompatDelegate.MODE_NIGHT_YES
                            : AppCompatDelegate.MODE_NIGHT_NO
            );
        });
    }


    /**
     * Displays a message when a module is unavailable.
     */
    private void showModuleNotReady() {

        Toast.makeText(
                this,
                R.string.module_not_ready,
                Toast.LENGTH_SHORT
        ).show();
    }
}
