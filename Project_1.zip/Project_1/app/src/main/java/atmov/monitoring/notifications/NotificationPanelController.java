
package atmov.monitoring.notifications;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import atmov.monitoring.R;

/**
 * Manages the notification panel displayed on the main screen.
 * Creates notification cards, handles swipe-to-dismiss
 * gestures, and updates the empty state.
 */
public class NotificationPanelController {

    private final Context context;
    private final LinearLayout notificationsContainer;
    private final TextView tvEmptyNotifications;

    /**
     * Initializes the notification panel.
     * @param context Context used to create views.
     * @param notificationsContainer Container for notification cards.
     * @param tvEmptyNotifications Message displayed when the list is empty.
     */
    public NotificationPanelController(
            Context context,
            LinearLayout notificationsContainer,
            TextView tvEmptyNotifications) {

        this.context = context;
        this.notificationsContainer = notificationsContainer;
        this.tvEmptyNotifications = tvEmptyNotifications;

        updateEmptyState();
    }


    /**
     * Creates and displays a new notification.
     * @param title Notification title.
     * @param message Notification description.
     */
    public void addNotification(String title, String message) {

        // Create the notification card.
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);

        card.setPadding(
                dp(14), dp(12), dp(14), dp(12)
        );

        card.setBackgroundResource(R.drawable.bg_alarm_item);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.bottomMargin = dp(8);


        // Create the notification title.
        TextView titleView = new TextView(context);

        titleView.setText(title);
        titleView.setTextSize(15);
        titleView.setTypeface(null, Typeface.BOLD);

        titleView.setTextColor(
                ContextCompat.getColor(
                        context,
                        R.color.warning_text
                )
        );

        card.addView(titleView);


        // Create the notification description.
        TextView messageView = new TextView(context);

        messageView.setText(message);
        messageView.setTextSize(13);

        messageView.setTextColor(
                ContextCompat.getColor(
                        context,
                        R.color.text_secondary
                )
        );

        card.addView(messageView);


        // Display the notification.
        notificationsContainer.addView(card, params);

        enableSwipeToDismiss(card);
        updateEmptyState();
    }


    /**
     * Enables horizontal swiping to dismiss a notification.
     * @param card Notification card.
     */
    @SuppressLint("ClickableViewAccessibility")
    private void enableSwipeToDismiss(View card) {

        final float[] startX = {0f};
        final float[] startY = {0f};
        final boolean[] swiping = {false};

        card.setClickable(true);

        card.setOnTouchListener((view, event) -> {

            float differenceX = event.getRawX() - startX[0];
            float differenceY = event.getRawY() - startY[0];

            switch (event.getActionMasked()) {

                case MotionEvent.ACTION_DOWN:

                    startX[0] = event.getRawX();
                    startY[0] = event.getRawY();

                    swiping[0] = false;
                    return true;


                case MotionEvent.ACTION_MOVE:

                    // Allow vertical scrolling.
                    if (!swiping[0]
                            && Math.abs(differenceY) > dp(10)
                            && Math.abs(differenceY)
                            > Math.abs(differenceX)) {

                        return false;
                    }

                    // Detect horizontal swiping.
                    if (Math.abs(differenceX) > dp(10)
                            && Math.abs(differenceX)
                            > Math.abs(differenceY)) {

                        swiping[0] = true;

                        view.getParent()
                                .requestDisallowInterceptTouchEvent(true);
                    }

                    if (swiping[0]) {

                        view.setTranslationX(differenceX);

                        float alpha = Math.max(
                                0.3f,
                                1f - Math.abs(differenceX)
                                        / Math.max(1, view.getWidth())
                        );

                        view.setAlpha(alpha);
                    }

                    return true;


                case MotionEvent.ACTION_UP:

                    if (swiping[0]
                            && Math.abs(differenceX) > dp(70)) {

                        // Animate the notification removal.
                        float direction = differenceX > 0
                                ? view.getWidth()
                                : -view.getWidth();

                        view.animate()
                                .translationX(direction)
                                .alpha(0f)
                                .setDuration(200)
                                .withEndAction(() -> {

                                    notificationsContainer.removeView(view);
                                    updateEmptyState();

                                })
                                .start();

                    } else {

                        // Restore the original position.
                        view.animate()
                                .translationX(0f)
                                .alpha(1f)
                                .setDuration(180)
                                .start();

                        if (!swiping[0]) {
                            view.performClick();
                        }
                    }

                    return true;


                case MotionEvent.ACTION_CANCEL:

                    view.animate()
                            .translationX(0f)
                            .alpha(1f)
                            .setDuration(180)
                            .start();

                    return true;
            }

            return false;
        });
    }


    /**
     * Shows the empty message when no notifications exist.
     */
    private void updateEmptyState() {

        int notificationCount = notificationsContainer.getChildCount();

        if (tvEmptyNotifications.getParent() == notificationsContainer) {
            notificationCount--;
        }

        tvEmptyNotifications.setVisibility(
                notificationCount == 0
                        ? View.VISIBLE
                        : View.GONE
        );
    }


    /**
     * Converts dp values to pixels.
     * @param value Dimension in dp.
     * @return Dimension in pixels.
     */
    private int dp(int value) {

        return Math.round(
                value * context.getResources()
                        .getDisplayMetrics()
                        .density
        );
    }
}
