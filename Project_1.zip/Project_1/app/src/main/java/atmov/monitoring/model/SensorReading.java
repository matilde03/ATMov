package atmov.monitoring.model;
/**
 * Represents a reading recorded by a sensor.
 * Stores the sensor type, the measured value,
 * and the timestamp indicating when the reading was recorded.
 */
public class SensorReading {
    public final String sensorType;

    public final double value;

    public final long timestamp;
    /**
     * Creates a SensorReading object with the specified data.
     * @param sensorType Type of sensor.
     * @param value Value measured by the sensor.
     * @param timestamp Timestamp of the reading.
     */
    public SensorReading(
            String sensorType,
            double value,
            long timestamp) {

        this.sensorType = sensorType;
        this.value = value;
        this.timestamp = timestamp;
    }
}
