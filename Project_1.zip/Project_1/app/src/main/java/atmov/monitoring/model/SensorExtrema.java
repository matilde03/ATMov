package atmov.monitoring.model;
/**
 * Represents the minimum and maximum values recorded by a sensor.
 * Stores the minimum and maximum readings, along with
 * the timestamps indicating when these values were recorded.
 */
public class SensorExtrema {
    public final double minValue;

    public final long minTimestamp;

    public final double maxValue;

    public final long maxTimestamp;

    /**
     * Creates a SensorExtrema object with the specified values.
     * @param minValue Minimum recorded value.
     * @param minTimestamp Timestamp of the minimum value.
     * @param maxValue Maximum recorded value.
     * @param maxTimestamp Timestamp of the maximum value.
     */

    public SensorExtrema(
            double minValue,
            long minTimestamp,
            double maxValue,
            long maxTimestamp) {

        this.minValue = minValue;
        this.minTimestamp = minTimestamp;
        this.maxValue = maxValue;
        this.maxTimestamp = maxTimestamp;
    }
}
