package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

public class ConfigActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_config);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Toolbar toolbar = findViewById(R.id.toolbarConfig);
        toolbar.setNavigationOnClickListener(v -> finish());

        Preferences prefs = new Preferences(this);

        SwitchCompat switchNotification = findViewById(R.id.switchNotificationMode);
        switchNotification.setChecked(prefs.isNotificationMode());
        switchNotification.setOnCheckedChangeListener((buttonView, isChecked) -> prefs.setNotificationMode(isChecked));

        SwitchCompat switchTempAlarm = findViewById(R.id.switchTempAlarm);
        switchTempAlarm.setChecked(prefs.isTempAlarmEnabled());
        switchTempAlarm.setOnCheckedChangeListener((buttonView, isChecked) -> prefs.setTempAlarmEnabled(isChecked));

        SwitchCompat switchHumidityAlarm = findViewById(R.id.switchHumidityAlarm);
        switchHumidityAlarm.setChecked(prefs.isHumidityAlarmEnabled());
        switchHumidityAlarm.setOnCheckedChangeListener((buttonView, isChecked) -> prefs.setHumidityAlarmEnabled(isChecked));

        SwitchCompat switchLuminosityAlarm = findViewById(R.id.switchLuminosityAlarm);
        switchLuminosityAlarm.setChecked(prefs.isLuminosityAlarmEnabled());
        switchLuminosityAlarm.setOnCheckedChangeListener((buttonView, isChecked) -> prefs.setLuminosityAlarmEnabled(isChecked));

        TextInputEditText etTempHigh = findViewById(R.id.etTempHigh);
        TextInputEditText etTempLow = findViewById(R.id.etTempLow);
        TextInputEditText etHumidityHigh = findViewById(R.id.etHumidityHigh);
        TextInputEditText etHumidityLow = findViewById(R.id.etHumidityLow);
        TextInputEditText etLuminosityHigh = findViewById(R.id.etLuminosityHigh);
        TextInputEditText etLuminosityLow = findViewById(R.id.etLuminosityLow);

        etTempHigh.setText(String.valueOf(prefs.getTempHigh()));
        etTempLow.setText(String.valueOf(prefs.getTempLow()));
        etHumidityHigh.setText(String.valueOf(prefs.getHumidityHigh()));
        etHumidityLow.setText(String.valueOf(prefs.getHumidityLow()));
        etLuminosityHigh.setText(String.valueOf(prefs.getLuminosityHigh()));
        etLuminosityLow.setText(String.valueOf(prefs.getLuminosityLow()));

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> {
            try {
                if (etTempHigh.getText() != null) prefs.setTempHigh(Float.parseFloat(etTempHigh.getText().toString()));
                if (etTempLow.getText() != null) prefs.setTempLow(Float.parseFloat(etTempLow.getText().toString()));
                if (etHumidityHigh.getText() != null) prefs.setHumidityHigh(Float.parseFloat(etHumidityHigh.getText().toString()));
                if (etHumidityLow.getText() != null) prefs.setHumidityLow(Float.parseFloat(etHumidityLow.getText().toString()));
                if (etLuminosityHigh.getText() != null) prefs.setLuminosityHigh(Float.parseFloat(etLuminosityHigh.getText().toString()));
                if (etLuminosityLow.getText() != null) prefs.setLuminosityLow(Float.parseFloat(etLuminosityLow.getText().toString()));
                Toast.makeText(this, R.string.config_saved, Toast.LENGTH_SHORT).show();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid threshold numbers", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(v -> {
            prefs.resetMinMax();
            Toast.makeText(this, R.string.min_max_reset_done, Toast.LENGTH_SHORT).show();
        });
    }
}
